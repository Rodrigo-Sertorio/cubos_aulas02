"use strict";
// BoasVindas.ts
Object.defineProperty(exports, "__esModule", { value: true });
// Função que mostra a mensagem de boas-vindas
function mostrarBoasVindas(nome) {
    console.log("BEM-VINDO, ".concat(nome));
}
// Testando a função com um nome de usuário
mostrarBoasVindas("Rodrigo");
// Exporta a função como padrão (caso você queira usar em outros arquivos)
exports.default = mostrarBoasVindas;
