"use strict";
// src/exercicio-01/novoSaldo.ts
Object.defineProperty(exports, "__esModule", { value: true });
// Função para calcular o novo saldo
function calcularNovoSaldo(saldoAtual, valor) {
    var novoSaldo = saldoAtual + valor;
    // Verificação para evitar saldo negativo
    if (novoSaldo < 0) {
        throw new Error("Saldo insuficiente para esta operação.");
    }
    return novoSaldo;
}
// Exemplo de uso da função
function exemploUso() {
    var saldoAtual = 1000; // saldo inicial
    var deposito = 500; // valor do depósito
    var saque = -200; // valor do saque
    try {
        var novoSaldoAposDeposito = calcularNovoSaldo(saldoAtual, deposito);
        console.log("Novo saldo ap\u00F3s dep\u00F3sito: R$ ".concat(novoSaldoAposDeposito.toFixed(2)));
        var novoSaldoAposSaque = calcularNovoSaldo(novoSaldoAposDeposito, saque);
        console.log("Novo saldo ap\u00F3s saque: R$ ".concat(novoSaldoAposSaque.toFixed(2)));
    }
    catch (error) {
        console.error(error.message);
    }
}
// Chama a função de exemplo
exemploUso();
exports.default = calcularNovoSaldo;
