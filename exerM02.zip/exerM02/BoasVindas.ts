// BoasVindas.ts

// Função que mostra a mensagem de boas-vindas
function mostrarBoasVindas(nome: string): void {
    console.log(`BEM-VINDO, ${nome}`);
}

// Testando a função com um nome de usuário
mostrarBoasVindas("Rodrigo");

// Exporta a função como padrão (caso você queira usar em outros arquivos)
export default mostrarBoasVindas;
