// src/exercicio-04/verificarPremiado.ts

// Define o tipo Pessoa
type Pessoa = {
    nome: string;
    numeroCartela: number;
};

// Função que verifica se alguém ganhou
function verificarPremiado(numeroSorteado: number, pessoasConcorrendo: Pessoa[]): string | undefined {
    const ganhador = pessoasConcorrendo.find(pessoa => pessoa.numeroCartela === numeroSorteado);
    return ganhador ? ganhador.nome : undefined;
}

// Exporta a função como padrão
export default verificarPremiado;

// Código de teste para verificar a função
if (require.main === module) {
    // Teste 1
    const numeroSorteado1 = 3;
    const pessoasConcorrendo1 = [
        { nome: "Matheus", numeroCartela: 4 },
        { nome: "Diego", numeroCartela: 1 },
        { nome: "Rodrigo", numeroCartela: 3 },
        { nome: "Karen", numeroCartela: 2 },
        { nome: "Leandro", numeroCartela: 5 },
    ];

    console.log(verificarPremiado(numeroSorteado1, pessoasConcorrendo1)); // "Pedro"

    // Teste 2
    const numeroSorteado2 = 7;
    const pessoasConcorrendo2 = [
        { nome: "Matheus", numeroCartela: 4 },
        { nome: "Diego", numeroCartela: 1 },
        { nome: "Rodrigo", numeroCartela: 3 },
        { nome: "Karen", numeroCartela: 2 },
        { nome: "Leandro", numeroCartela: 5 },
    ];

    console.log(verificarPremiado(numeroSorteado2, pessoasConcorrendo2)); // undefined
}
