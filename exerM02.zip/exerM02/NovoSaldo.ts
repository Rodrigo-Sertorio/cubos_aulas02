// src/exercicio-01/novoSaldo.ts

// Função para calcular o novo saldo
function calcularNovoSaldo(saldoAtual: number, valor: number): number {
    const novoSaldo = saldoAtual + valor;
    
    // Verificação para evitar saldo negativo
    if (novoSaldo < 0) {
        throw new Error("Saldo insuficiente para esta operação.");
    }

    return novoSaldo;
}

// Exemplo de uso da função
function exemploUso() {
    const saldoAtual: number = 1000; // saldo inicial
    const deposito: number = 500;      // valor do depósito
    const saque: number = -200;        // valor do saque

    try {
        const novoSaldoAposDeposito = calcularNovoSaldo(saldoAtual, deposito);
        console.log(`Novo saldo após depósito: R$ ${novoSaldoAposDeposito.toFixed(2)}`);

        const novoSaldoAposSaque = calcularNovoSaldo(novoSaldoAposDeposito, saque);
        console.log(`Novo saldo após saque: R$ ${novoSaldoAposSaque.toFixed(2)}`);
    } catch (error) {
        console.error(error.message);
    }
}

// Chama a função de exemplo
exemploUso();

export default calcularNovoSaldo;
