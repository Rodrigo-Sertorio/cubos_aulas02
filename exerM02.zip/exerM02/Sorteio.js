"use strict";
// src/exercicio-04/verificarPremiado.ts
Object.defineProperty(exports, "__esModule", { value: true });
// Função que verifica se alguém ganhou
function verificarPremiado(numeroSorteado, pessoasConcorrendo) {
    var ganhador = pessoasConcorrendo.find(function (pessoa) { return pessoa.numeroCartela === numeroSorteado; });
    return ganhador ? ganhador.nome : undefined;
}
// Exporta a função como padrão
exports.default = verificarPremiado;
// Código de teste para verificar a função
if (require.main === module) {
    // Teste 1
    var numeroSorteado1 = 3;
    var pessoasConcorrendo1 = [
        { nome: "Matheus", numeroCartela: 4 },
        { nome: "Diego", numeroCartela: 1 },
        { nome: "Rodrigo", numeroCartela: 3 },
        { nome: "Karen", numeroCartela: 2 },
        { nome: "Leandro", numeroCartela: 5 },
    ];
    console.log(verificarPremiado(numeroSorteado1, pessoasConcorrendo1)); // "Pedro"
    // Teste 2
    var numeroSorteado2 = 7;
    var pessoasConcorrendo2 = [
        { nome: "Matheus", numeroCartela: 4 },
        { nome: "Diego", numeroCartela: 1 },
        { nome: "Rodrigo", numeroCartela: 3 },
        { nome: "Karen", numeroCartela: 2 },
        { nome: "Leandro", numeroCartela: 5 },
    ];
    console.log(verificarPremiado(numeroSorteado2, pessoasConcorrendo2)); // undefined
}
