"use strict";
// src/exercicio-03/verificarValidade.ts
Object.defineProperty(exports, "__esModule", { value: true });
// Função que verifica se a moeda é válida
function verificarValidade(valorLido, valoresValidos) {
    return valoresValidos.includes(valorLido);
}
// Exporta a função como padrão
exports.default = verificarValidade;
// Código de teste para verificar a função
if (require.main === module) {
    var valoresValidos = [0.01, 0.05, 0.10, 0.25, 0.50, 1.00];
    console.log(verificarValidade(0.25, valoresValidos)); // true
    console.log(verificarValidade(0.03, valoresValidos)); // false
    console.log(verificarValidade(1.00, valoresValidos)); // true
    console.log(verificarValidade(2.00, valoresValidos)); // false
}
