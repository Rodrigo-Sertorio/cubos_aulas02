function nomeCompleto(nome, sobrenome) {
    const nomeUsuario = `${nome} ${sobrenome}`
    return nomeUsuario
}

const imprimir = nomeCompleto('Rodrigo', 'Sertorio')

    console.log(imprimir)

function verificaIdade(idade) {
	if (idade <= 17) {
		return 'Não é maior de idade'
	}

	return 'É maior de idade'
}

// arrow function

const verificaIdade2 = (idade) => {
	if (idade <= 17) {
		return 'Não é maior de idade'
	}

	return 'É maior de idade'
}

console.log(verificaIdade2(45))