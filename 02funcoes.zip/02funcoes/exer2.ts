// Faça uma função que tem um parâmetro chamado idade e que determina a 
// faixa etária de uma pessoa a partir dessa idade.

// 21 anos ou menos -> jovem
// 22 a 65 anos -> adulto(a)
// 66 ou mais anos -> idoso(a)

// Sua função deverá retornar um string que informa se a pessoa é jovem, adulto(a) ou idoso(a)

function faixaEtaria(idade) {
	if (idade <= 21) {
		return 'jovem'
	} else if (idade <= 65) {
		return 'adulto(a)'
	} else {
		return 'idoso(a)'
	}
}

console.log(faixaEtaria(20))
console.log(faixaEtaria(22))
console.log(faixaEtaria(70))

const faixaEtaria2 = (idade) => {
	if (idade <= 21) {
		return 'jovem'
	}

	if (idade <= 65) {
		return 'adulto(a)'
	}

	return 'idoso(a)'
}

console.log(faixaEtaria2(20))
console.log(faixaEtaria2(22))
console.log(faixaEtaria2(70))