type TUsuario = {
	nome: string
	idade: number
	email: string
}

const usuarios: TUsuario[] = []

function cadastrarUsuario(usuario: TUsuario) {
	usuarios[usuarios.length] = usuario
	return usuario
}

const resultado = cadastrarUsuario({
	nome: 'Rodrigo',
	email: 'rodrigo09.sertorio@live.com',
	idade: 45
})

console.log(resultado)
console.log(usuarios)