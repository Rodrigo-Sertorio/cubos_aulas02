// Declare uma variável que armazena um objeto contendo 
// dados de uma pessoa: nome, idade, profissão e altura.

// Faça uma função que tem um parâmetro. Essa função deve 
// imprimir na tela a apresentação de uma pessoa, seguindo o modelo abaixo:

// "Olá! Meu nome é João, sou um jovem de 12 anos, 1.4m de altura e sou estudante"

const usuario = {
	nome: 'Rodrigo Sertorio',
	idade: 45,
	profissao: 'Dev',
	altura: 1.80
}

function apresentacao(dadosUsuario) {
	console.log(`Olá! Meu nome é ${dadosUsuario.nome}, sou um jovem 
	de ${dadosUsuario.idade} anos, ${dadosUsuario.altura}m de altura e sou ${dadosUsuario.profissao}`)
}

apresentacao(usuario)