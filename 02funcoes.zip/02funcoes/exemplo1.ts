function saudacao() {
	console.log('Olá pessoal!')
}

saudacao()
saudacao()
saudacao()
saudacao()
saudacao()
saudacao()