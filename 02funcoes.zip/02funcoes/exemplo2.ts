const usuarios = []

// function cadastrarUsuario(nome, email, idade) {
// 	usuarios[usuarios.length] = {
// 		nome, email, idade
// 	}
// }

// cadastrarUsuario('Rodrigo', 'rodrigo09.sertorio@gmail.com', 45)

// console.log(usuarios)

// cadastrarUsuario('Cardoso', 'rodrigo09.sertorio@live.com', 22)

// console.log(usuarios)

function cadastrarUsuario(usuario) {
	usuarios[usuarios.length] = {
		nome: usuario.nome, 
		email: usuario.email, 
		idade: usuario.idade
	}
}

cadastrarUsuario({
	nome: 'Rodrigo',
	email: 'rodrigo09.sertorio@gmail.com',
	idade: 45
})

console.log(usuarios)

const Sertorio = {
	nome: 'Sertorio',
	email: 'rodrigosertorio2008@hotmail.com',
	idade: 20
}

cadastrarUsuario(Sertorio)

console.log(usuarios)